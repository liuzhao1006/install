<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>main</name>
    <message>
        <source>Hello    World</source>
        <translation type="obsolete">慕影播放器</translation>
    </message>
    <message>
        <source>Press    Me</source>
        <translation type="vanished">按我</translation>
    </message>
    <message>
        <source>MuYing    Player</source>
        <translation type="vanished">慕影播放器</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="14"/>
        <source>MuYing Player</source>
        <translation>慕影播放器</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="196"/>
        <source>Choose the video.</source>
        <translation>选择视频。</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="201"/>
        <source>Video files(*.mp4 *.rmvb *.flv)</source>
        <translation>视频文件(*.mp4 *.rmvb *.flv)</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="201"/>
        <location filename="../qml/main.qml" line="271"/>
        <location filename="../qml/main.qml" line="390"/>
        <source>All files(*)</source>
        <translation>所有文件(*)</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="266"/>
        <source>Choose the subtitle.</source>
        <translation>选择字幕。</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="271"/>
        <source>Subtitle files(*.srt *.ssa *.ass)</source>
        <translation>字幕文件(*.srt *.ssa *.ass)</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="385"/>
        <source>Choose the picture.</source>
        <translation>选择图片。</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="390"/>
        <source>Image files(*.png *.jpg *.bmp)</source>
        <translation>图片文件(*.png *.jpg *.bmp)</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="458"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="465"/>
        <source>Chinese</source>
        <translation>中文</translation>
    </message>
    <message>
        <location filename="../qml/main.qml" line="471"/>
        <source>English</source>
        <translation>英文</translation>
    </message>
</context>
</TS>
